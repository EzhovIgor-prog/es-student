#pragma once

#define FIRMWARE_NAME "es-led-module"
#define FIRMWARE_VERSION "1.1.0"

#define FIRMWARE_PROJECT "231-firmware-template"
#define FIRMWARE_REPO "https://github.com/EzhovIgor-prog/es-student"

