#include "led-task/led-task.h"
#include "hardware/gpio.h"

const uint LED_PIN = 25;

#define PICO_DEFAULT_LED_PIN 25

#define LED_HALF_PERIOD_US 500000

led_state_t led_state = LED_STATE_OFF;


bool led_on = false;
bool led_blinking = false;
//uint64_t last_toggle_us = 0;

static led_state_t led_state= LED_STATE_OFF;
static uint64_t half_period_us;
static uint64_t last_toggle_us;


void led_init(void)
{
    // инициализируем пин светодиода и настраиваем его на выход
    gpio_init(LED_PIN);
    gpio_set_dir(LED_PIN, GPIO_OUT);

    led_set(false);
}

void led_set(bool on)
{
    led_state = on;
    gpio_put(LED_PIN, led_state);
}

void led_toggle(void)
{
    
    led_set(!led_state);
}

bool led_is_on(void)
{
    return led_state;
}

uint led_pin(void)
{
    return (uint)LED_PIN;

}

// Вспомогательная функция: из других файлов её не вызвать
static void led_set(bool on)
{
    gpio_put(PICO_DEFAULT_LED_PIN, on);
}



bool period_elapsed(uint64_t *last_us, uint64_t period_us)
{
    uint64_t now_us = time_us_64();

    if (now_us - *last_us < period_us) {
        return false;
    }

    // Следующее срабатывание отсчитывается от прошлого, а не от «сейчас»
    *last_us += period_us;

    // Отстали больше чем на период: не догонять, а начать отсчёт заново
    if (now_us - *last_us >= period_us) {
        *last_us = now_us;
    }

    return true;
}


void led_task_handle(void)
{
    // Переключить светодиод, если прошёл полупериод мигания
    if (period_elapsed(&last_toggle_us, half_period_us)) {
        gpio_put(PICO_DEFAULT_LED_PIN, !gpio_get(PICO_DEFAULT_LED_PIN));
    }
}


void led_task_handle(void)
{
    if (led_blinking) {
        // Мигание: переключать светодиод каждый полупериод
        if (period_elapsed(&last_toggle_us, half_period_us)) {
            gpio_put(PICO_DEFAULT_LED_PIN, !gpio_get(PICO_DEFAULT_LED_PIN));
        }
    } else {
        gpio_put(PICO_DEFAULT_LED_PIN, led_on);
    }
}



void led_task_set_state(led_state_t state)
{
    led_state = state;

    // Действие при входе: выполняется один раз, в момент перехода
    switch (led_state) {
    case LED_STATE_OFF:
        gpio_put(PICO_DEFAULT_LED_PIN, false);
        break;
    case LED_STATE_ON:
        gpio_put(PICO_DEFAULT_LED_PIN, true);
        break;
    case LED_STATE_BLINK:
        // Первое переключение — на ближайшей итерации
        last_toggle_us = 0;
        break;
    }
}

void led_task_handle(void)
{
    switch (led_state) {
    case LED_STATE_OFF:
    case LED_STATE_ON:
        // Светодиод установлен при входе в состояние, делать нечего
        break;
    case LED_STATE_BLINK:
        if (period_elapsed(&last_toggle_us, half_period_us)) {
            gpio_put(PICO_DEFAULT_LED_PIN, !gpio_get(PICO_DEFAULT_LED_PIN));
        }
        break;
    }
}

void led_task_init(void);
{


    half_period_us  = LED_HALF_PERIOD_US;

    
}


bool led_task_set_period_ms(uint32_t period_ms)
{
    // С нулевым полупериодом светодиод переключался бы
    // на каждой итерации: такой период не принимается
    if (period_ms == 0) {
        return false;
    }

    half_period_us = (uint64_t)period_ms * 1000 / 2;
    return true;
}

bool led_task_get_state(void)
{



}

bool led_task_next_state(void)
{


    
}