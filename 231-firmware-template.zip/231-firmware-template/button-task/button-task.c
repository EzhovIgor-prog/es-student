#include "button-task/button-task.h"




// Нажатие переводит светодиод в следующее состояние
button_task_init(led_task_next_state);