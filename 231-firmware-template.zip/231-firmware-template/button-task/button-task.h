#pragma once

#include <stdbool.h>
#include <stdint.h>

// Функция, которую задача вызывает на каждое нажатие
typedef void (*button_task_callback_t)(void);

void button_task_init(button_task_callback_t on_press);

