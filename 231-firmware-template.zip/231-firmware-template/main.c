#include "pico/stdlib.h"
#include <stdio.h>
#include "pico/stdlib.h"
#include "led.h"
#include "log.h"
#include "device.h"
#include <string.h>

#include "command.h"

#include "profiling.h"




typedef void (*command_handler_t)(void);



#define LINE_SIZE 32

char line[LINE_SIZE];
uint line_length = 0;

const uint BLINK_HALF_PERIOD_MS = 500;

uint64_t last_toggle_us = 0;



//=====================================================================





//====================================================================
void read_line(void)
{
    int symbol = getchar_timeout_us(0);

    if (symbol == PICO_ERROR_TIMEOUT)
    {
        return;
    }

    if (symbol == '\r' || symbol == '\n')
    {
        putchar('\n');
        line[line_length] = '\0';

        if (line_length > 0)
        {
            LOG_DBG("got %s\n", line);
            handle_command(line);
        }

        line_length = 0;
        return;
    }

    if (line_length + 1 < LINE_SIZE)
    {
        line[line_length] = (char)symbol;
        line_length = line_length + 1;
        putchar(symbol);
    }
}




void blink(void)
{
    uint64_t now_us = time_us_64();

    if (now_us - last_toggle_us >= BLINK_HALF_PERIOD_MS * 1000)
    {
        last_toggle_us = now_us;
        led_toggle();
    }
}




//========================================================================
int main()
{
   stdio_text_protocol_init();
// Каждая задача инициализируется один раз
    command_task_init();
    led_task_init();

    // Суперцикл по очереди вызывает обработчики задач
    while (true) {
        command_task_handle();
        led_task_handle();
    }

// принятая строка становится командой, команда — действием прибора
const command_t *command = stdio_text_protocol_handle();
if (command != NULL)
{
    api_handle(command);
}



    stdio_init_all();

    led_init();

    

    

    profiling_init();

   while (1)
    {
        profiling_iteration();
        
        blink();
        read_line();

        
    }
}