#include "api.h"



// прикидка: за член ряда 4 операции с double, 175 + 110 + 190 + 110 = 585 тактов;
// 1 000 000 членов по 585 тактов при 125 МГц — около 4,7 с
//const uint CALC_PI_TERMS = 1000000;
//volatile double pi_result;

#define PI_TERMS_PER_CALL 100

// Состояние расчёта: должно пережить возврат из обработчика
bool pi_running = false;
bool pi_ready = false;
int pi_k;
int pi_n;
double pi_sum;
double pi_sign;
double pi_result;

double pi;

/*
double calc_pi(uint n)
{
    double sum = 0.0;
    double sign = 1.0;

    for (int k = 0; k < n; k++) {
        // Прибавить очередной член ряда: ±1 / (2k + 1)
        sum += sign / (2.0 * k + 1.0);
        sign = -sign;
    }

    // Сумма ряда равна π/4
    return 4.0 * sum;
}




void cmd_calc_pi(void)
{
    uint64_t start_us = time_us_64();
    pi_result = calc_pi(CALC_PI_TERMS);
    uint64_t spent_us = time_us_64() - start_us;

    printf("pi: %.8f\n", pi_result);
    printf("time: %llu ms\n", spent_us / 1000);
}



void cmd_info(void)
{
    // печатаем паспорт устройства
    device_info();
}




void cmd_uptime(void)
{
   //uptime();
}

void cmd_time_exec(void)
{
   time_exec();
}

void cmd_time_reset(void)
{
   time_reset();
}




//=======================================================

const struct command_t commands[] = {
    { "info", cmd_info },
    { "uptime", cmd_uptime }, 
    { "calc_pi", cmd_calc_pi },
    { "main_time_exec", cmd_time_exec },
    { "main_time_reset", cmd_time_reset }, 

};

const uint command_count = sizeof(commands) / sizeof(commands[0]);






//=====================================================================
void handle_command(const char *command)
{
    for (uint i = 0; i < command_count; i++)
    {
        if (strcmp(command, commands[i].name) == 0)
        {
            if (commands[i].handler != NULL)
            {
                commands[i].handler();
            }

            return;
        }
    }

    LOG_ERR("unknown command: %s\n", command);
}
*/




void api_handle(const command_t *command)
{









}







void pi_task_start(int n)
{
    pi_n = n;
    pi_k = 0;
    pi_sum = 0.0;
    pi_sign = 1.0;
    pi_ready = false;
    pi_running = true;
}

void pi_task_handle(void)
{
    if (!pi_running) {
        return;
    }

    // Очередная порция членов ряда, но не дальше последнего
    int end = pi_k + PI_TERMS_PER_CALL;
    if (end > pi_n) {
        end = pi_n;
    }
    for (; pi_k < end; pi_k++) {
        pi_sum += pi_sign / (2.0 * pi_k + 1.0);
        pi_sign = -pi_sign;
    }

    if (pi_k == pi_n) {
        pi_result = 4.0 * pi_sum;
        pi_running = false;
        pi_ready = true;
    }
}

// Готов ли результат: если да, записать его по указателю
bool pi_task_get_result(double *result)
{
    if (!pi_ready) {
        return false;
    }
    *result = pi_result;
    return true;
}



// Ответить значением или сообщить, что расчёт ещё идёт
if (pi_task_get_result(&pi)) {
    printf("pi = %f\n", pi);
} else {
    printf("busy\n");
}




